package com.example.myapplication;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class menugui extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.menugui_layout);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ListView listView = findViewById(R.id.transaction_history);
        List<Map<String, String>> trData = new ArrayList<>();
        trItem(trData, "+100.00", "3/14/25 9:38:00");
        trItem(trData, "-280.00", "3/14/25 12:04:54");
        trItem(trData, "+1000.00", "4/25/25 10:17:45");
        trItem(trData, "-1000.00", "4/25/25 10:20:59");
        trItem(trData, "-200.00", "5/3/25 19:50:23");
        String[] from = {"add_sub", "time"};
        int[] to = {android.R.id.text1, android.R.id.text2};

        SimpleAdapter adapter = new SimpleAdapter(this, trData, android.R.layout.simple_list_item_2, from, to);
        listView.setAdapter(adapter);
        listView.setPadding(0, 0, 0, 0);
        listView.setClipToPadding(false);
    }

    private void trItem(List<Map<String, String>> list, String title, String subtitle) {
        Map<String, String> item = new HashMap<>();
        item.put("add_sub", title);
        item.put("time", subtitle);
        list.add(item);
    }
}