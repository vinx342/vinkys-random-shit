package com.example.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText login;
    EditText password;
    Button buttones;
    Button retrybuttones;
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        login = findViewById(R.id.log_text);
        password = findViewById(R.id.pass_text);
        buttones = findViewById(R.id.registerbutton);
        dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.wronglogin_dialog);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.dialog_thingy));
        dialog.setCancelable(false);

        retrybuttones = dialog.findViewById(R.id.retry_button);

        retrybuttones.setOnClickListener(v -> dialog.dismiss());

        buttones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String log_text = login.getText().toString();
                String pass_text = password.getText().toString();

                if(log_text.equalsIgnoreCase("vongabriel@gmail.com") && pass_text.equalsIgnoreCase("osorio"))
                {
                    Toast.makeText(MainActivity.this,"Welcome to YWAMoney", Toast.LENGTH_SHORT).show();
                    Intent newActivity = new Intent(MainActivity.this, menugui.class);
                    startActivity(newActivity);
                    finish();
                } else {
                    dialog.show();
                }
            }
        });
    }
}